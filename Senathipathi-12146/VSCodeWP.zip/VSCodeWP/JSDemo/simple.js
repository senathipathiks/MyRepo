var x="Senathipathi"
var y="4";
var c=true;
x=4;

document.write("<b><u>"+"Hello World"+"</b></u>");
document.write("<br>"+"This is my First Line"+(x===y));
