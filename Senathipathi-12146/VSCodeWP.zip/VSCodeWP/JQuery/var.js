// for(let i=0;i<10;i++)
// setTimeout(() => {console.log(i);}, 1000);

// var value=function(){
//     return 10;
// }

// const res=()=>10;

// function fname()
// {
//     return value;
// }
// const fname=()=>value;


const arr=[10,20,30];
const newarr=arr.map(function(element){
     return element*3;
 });

console.log(newarr);

// const [first,second,third]=arr;
// console.log(first);

// const[x, y,...rest]=newarr;
// console.log(rest);

// let obj={
//     firstname:"Arun",
//     middlename:"Sundar",
//     lastname:"Kumar"
// }

// const{firstname:fname,middlename:mname,lastname:lname}=obj

// console.log(fname);

// obj.name="Kumar"
// console.log(obj.name)
