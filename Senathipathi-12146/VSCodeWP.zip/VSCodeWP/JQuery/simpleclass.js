<html>
    <head>
      
    </head>
    <body>
        
    <script>
        class student
        {
            constructor(stuname)
            {
                this.stuname=stuname;
            }
            display()
            {
                document.write(stuname);
            }
        }
        student stu=new student("Arun");
        stu.display();
    </script> 
    </body>
</html>