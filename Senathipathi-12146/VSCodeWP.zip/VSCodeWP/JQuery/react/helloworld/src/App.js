// import logo from './logo.svg';
import './App.css';
import Greet from './Welcome';
import Welcome from './second';

function App() {
  // return (
  //   <div className='App'>
  // <Greet />
  // <Welcome />
  // </div>
  // );
}

export default App;
