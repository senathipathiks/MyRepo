import React, { Component } from 'react'
import ReactDOM from 'react-dom'
class Greet extends Component{
    render()
    {
        return <b> Welcome to My Page </b>;
    }
}

export default Greet;