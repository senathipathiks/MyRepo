import React from 'react'

// function Welcome()
//  {
//          return (
//             <div>
//            This is second Component
//             </div>
//             );
// }
const Welcome=()=>{return(
    <div>
    <ul align="left">
        <li>First</li>
        <li>Second</li>
        <li>Third</li>
    </ul>
    </div>
   );}

export default Welcome;