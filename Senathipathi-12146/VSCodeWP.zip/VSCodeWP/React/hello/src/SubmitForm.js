import React, { Component } from 'react'

class SubmitForm extends Component {
    constructor(props) {
        super(props);
        this.state = { firstName: "" };
      }
      formHandler = (event) => {
        this.setState({ firstName: event.target.value });
      };
      submitHandler = (event) => {
        event.preventDefault();
        window.alert("You submitted " + this.state.firstName);
      };
    
  render() {
    return (
      <div>
        <form onSubmit={this.submitHandler}>
        <p>Enter your name: {this.state.firstName} </p>
        <input onChange={this.formHandler} type="text" name="firstName" />
        <input onChange={this.formHandler} type="submit" />
      </form>
      </div>
    )
  }
}

export default SubmitForm
