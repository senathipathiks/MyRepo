import React, { memo, useState, useEffect } from "react";
import ReactDOM from "react-dom";

//import "./styles.css";

function Movie({ title, releaseDate }) {
  console.log(`${memo ? "<MemoizedMovie>" : "<Movie>"} rendered`);
  return (
    <div>
      <div>Movie title: {title}</div>
      <div>Release date: {releaseDate}</div>
    </div>
  );
}

const MemoizedMovie = React.memo(Movie);
export default Movie