import React from "react";

function Contact() {
    return (
        <address>
            You can find us here:
            <br />
            Relevantz
            <br />
            Chennai One IT SEZ <br />
            Chennai
        </address>
    );
}
 
export default Contact;