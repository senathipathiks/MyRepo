import React, { Component } from 'react';
import "./Mystyle.css"
class Myclassapp extends Component{
    
    constructor(props){
        super(props);
        this.state={date:new Date()}
    }
    render(){
        return(<div class="div2">
            This is my Class Component {this.props.name}
            <br /> Current Time is {this.state.date.toLocaleTimeString()}
        </div>)
    }
}

export default Myclassapp;
