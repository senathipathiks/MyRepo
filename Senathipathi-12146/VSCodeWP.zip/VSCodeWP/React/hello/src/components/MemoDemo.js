import { memo, useState } from 'react';

function MemoDemo() {
  const [name, setName] = useState(' ');
  const [address, setAddress] = useState('');

  return (
    <>
      <label>
        Name{': '}
        </label>
        <input value={name} 
        type="text"
        onChange={e => setName(e.target.value)} 
        />
      
    <br/>
      <label>
        Address{': '} 
     </label>
        <input value={address}
        type="address"  
        onChange={e => setAddress(e.target.value)} 
       />
      

      <Greeting name={name} />
      {/* setInterval(()=>{name}, 1000); */}

    </>
  );
}

const Greeting = memo(function Greeting({ name }) 
{
  console.log("Greeting was rendered at", new Date().toLocaleTimeString());
  
  return <h3>Hello{name && ', '}{name}!</h3>;

});

export default MemoDemo