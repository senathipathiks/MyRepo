import React, { Component } from 'react'

 class Conditionalrend extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
         flag:false
      }
    }
    
  render() {
    const trueEle=<div> Welcome Senathipathi </div>
    const falseEle=<div> Welcome Guest </div>
    if(this.state.flag)
        return (trueEle)
    else
    return (falseEle )
  
 //return (this.state.flag) ?  <div> Welcome Senathipathi </div> : <div> Welcome Guest </div> 
   }


}

export default Conditionalrend
