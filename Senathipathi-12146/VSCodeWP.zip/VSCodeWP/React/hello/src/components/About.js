import React from "react";

function About() {
    return (
        <div>
            <h2>
            We are in the business of custom software engineering.
            </h2>
            Read more about us at :
            <a href="www.relevantz.com">
            https://relevantz.com/about/
            </a>
        </div>
    );
}
export default About;