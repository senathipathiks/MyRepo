import React from 'react';
import "./Mystyle.css";

function Myapp(props){
    const{name,topic}=props
return (
    <div class="div1">
        <b> This is my First Component {name} created using {topic} </b>
        {props.children}
    </div>
);
}

export default Myapp;

