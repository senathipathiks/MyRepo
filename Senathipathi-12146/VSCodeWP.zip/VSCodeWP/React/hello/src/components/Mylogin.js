import React from 'react'
function Mylogin(){
    return(
        <div class="MyDivClass">
        <center>
        <table>
           
        <tr>
           <td> Email </td>
           <td> <input class="Txtstyle" type="text" /></td>
        </tr>
        <tr>
           <td> Password </td>
           <td> <input class="Txtstyle" type="password" /></td>
        </tr>
        <tr align="center">
           <td><input type="Submit" /></td>
           <td> <a class="aStyle" href="Registration page">New User Sign Up here !!! </a></td>
        </tr>
        
        </table>
    </center>
    </div>
    );
}

export default Mylogin;