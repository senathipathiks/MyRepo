import React, { Component } from 'react';
import "./Mystyle.css"
class List extends Component{
    constructor(){
        super();
        this.state={
            info:'Welcome to My Page'
        }
    }
    changemessage()
    {
        this.setState(
            {
                info:'Thanks for Subscribing !!!'
            }
        )
    }
    render(){
        return(<div class="div2">
           {this.state.info}
           <button onClick={()=>this.changemessage()}>Click Me for Subscribing !!! </button>
        </div>)
    }
}

export default List;