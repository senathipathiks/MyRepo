import React, { Component } from 'react'

class TextField extends Component {
    constructor() {
        super();
        this.state = { firstName: "" };
      }
      formHandler = (event) => {
        this.setState({ firstName: event.target.value });
      };
  render() {
    return (
      <div>
        <form>
        <p>Enter your name: {this.state.firstName} </p>
        <input type="text" onChange={this.formHandler} name="firstName" />
        <input type="submit" />
      </form>
      </div>
    )
  }
}

export default TextField
