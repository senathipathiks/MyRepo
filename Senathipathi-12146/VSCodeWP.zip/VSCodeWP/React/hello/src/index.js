import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
// import App from './components/App';
import Myapp from './components/Myapp';
import reportWebVitals from './reportWebVitals';
import Myclassapp from './components/Myclassapp';
import Mylogin from './components/Mylogin';
import List from './components/List';
import Mycounter from './components/Mycounter';
import Eventbind from './components/Eventbind';
import Myfunccounter from './components/Myfunccounter';
import Listrender from './components/Listrender';
import Conditionalrend from './components/Conditionalrend';
import User from './components/User';
import TextField from './TextField';
import SubmitForm from './SubmitForm';
import ValidationForm from './ValidationForm';
import RouterExample from './components/RouterExample';
import MemoDemo from './components/MemoDemo';
import Movie from './components/MemoExample2';
import ParentComponent from './components/ParentComponent';


const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
  {/* <Myapp />

    <Myapp name="Arun" topic="React" >
    <p>Hello All </p> 
    </Myapp>
    <Myclassapp name="World" />
    <Mylogin />
    <List />
   <Mycounter />
   <Myfunccounter />
    <Eventbind />
    <Listrender />
    <Conditionalrend /> */}
    {/* <User /> */}
    {/* <TextField /> */}
    {/* <SubmitForm /> */}
    {/* <ValidationForm /> */}
    {/* <RouterExample /> */}
    {/* <MemoDemo/> */}
<ParentComponent />
    {/* <Movie title= "Heat" releaseDate="2nd Jan"></Movie>
    <Movie title= "Heat" releaseDate="2nd Jan"></Movie> */}
    {/* <App /> */}
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
