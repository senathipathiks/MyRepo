import { useState, useEffect } from 'react';
import axios from 'axios';

const Axiosexam = () => {
   const [posts, setPosts] = useState([]);

   useEffect(() => {
      axios
         .get('https://jsonplaceholder.typicode.com/posts')
         .then((response) => {
            setPosts(response.data);
         })
         .catch((err) => {
            console.log(err);
         });
   }, []);

   return (
    <ul>
    {posts.map(x=><li>{x.id}</li>)}
  </ul>
   );
};

export default Axiosexam