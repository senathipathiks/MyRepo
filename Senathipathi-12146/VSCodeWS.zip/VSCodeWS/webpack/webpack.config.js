const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
module.exports={
    entry:'./app/index.js',
    module:
    {
        rules:[
                {
                    test: /\.svg$/,
                    use: 'svg-inline-loader'
                },
                {
                    test: /\.css$/i,
                    use: ["style-loader", "css-loader"],
                }, 
                // {
                //     test: /\.(js)$/,
                //     use: 'babel-loader',
                // }, 
                {
                test: /\.(js|jsx)$/,
                exclude: /(node_modules|bower_components)/,
                loader: 'babel-loader',
                options: { presets: ['@babel/env','@babel/preset-react'] },
                
              }

        ],
    },
    output: {
        filename: 'bundle.js',
        path:path.resolve(__dirname,"dist")
      },
    plugins: [
        new HtmlWebpackPlugin()
    ],
    mode:process.env.NODE_ENV==="production" ? "production" : "development"
};