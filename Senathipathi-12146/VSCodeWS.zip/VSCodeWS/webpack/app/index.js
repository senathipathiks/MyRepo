const myArray=["Sena","Gowtham","Arun","Aneesh"]

console.log(myArray);