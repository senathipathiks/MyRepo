import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
        <h1>Hi !!! </h1>
        </div>
  );
}

export default App;
