import {getByTestId, render, screen, fireEvent, getByText,waitFor } from '@testing-library/react';
import renderer  from 'react-test-renderer';
import App from './App';
import "@testing-library/jest-dom/extend-expect";


describe("My Test Cases",()=> {

// test("Snapshot test ", () => {
//   //render(<App />);
//   const comp = renderer.create(<App />)
//   const tree=comp.toJSON();
//   expect(tree).toMatchSnapshot();
// });
it("renders 'label' ", () => {
  render(<App />);
  const linkElement = screen.getByRole("label");
  expect(linkElement).toBeInTheDocument();
   
});
it("renders 'username text' ", () => {
  render(<App />);
  const linkElement = screen.getByRole("username");
  expect(linkElement).toBeInTheDocument();
  expect(linkElement).toHaveTextContent("");

});
it("renders 'label for password' ", () => {
  render(<App />);
  const linkElement = screen.getByRole("pwdlabel");
  expect(linkElement).toBeInTheDocument();
   
});
it("renders 'password text' ", () => {
  render(<App />);
  const linkElement = screen.getByRole("pwdtext");
  expect(linkElement).toBeInTheDocument();
  expect(screen.getByPlaceholderText("Enter Password")).toHaveTextContent("");

});
it("renders 'submit button' ", () => {
  render(<App />);
  const linkElement = screen.getByTestId("login-submit");
  expect(linkElement).toBeInTheDocument();
  expect(linkElement).toHaveTextContent("Login");

});
// it("renders 'submit button' ", () => {
//   render(<App />);
//   const linkElement = screen.getByTestId("login-submit");
//   expect(linkElement).toBeInTheDocument();
//   expect(linkElement).toHaveTextContent("Login");

// });

it("renders 'checkbox' ", () => {
  render(<App />);
  const linkElement = screen.getByTestId("checkbox");
  expect(linkElement).toBeInTheDocument();
  expect(linkElement).toBeChecked();

});

// });

// test('DOM test', () => {
// const html =
// '<div id="root">' +
// ' <input type="text" id="text">' +
// ' <button id="button">Ok</button>' +
// '</div>';
// document.body.innerHTML = html;

// const root = document.getElementById('root');

// expect(root.parentElement.innerHTML).toEqual(html);
});
