function add(one,two,three)  //rest operator
{
    var sum=0;
    // arr1.forEach(element => {
    //     sum+=element;
    // });
    return one+two+three;
}

let arr=[10,20,30];
let val=add(...arr); //spread operator
console.log(val);

