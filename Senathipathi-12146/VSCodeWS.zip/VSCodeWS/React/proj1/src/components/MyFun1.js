import  { useState } from 'react'

function MyFun1(props) {
    const {name:fname,age}=props;
    const [count,setCount]=useState(0);
    function changeCount()
    { 
        setCount(count+1)
    }
    
  return (
    <div>
        
      <h1>Welcome  {fname}, Your age is {age} </h1>
      <h1>{count}</h1>
        <button onClick={()=>{changeCount()}}>Click Me</button>
    </div>
  )
}


export default MyFun1
