import React, { Component } from 'react'

export class Greet extends Component {
    constructor()
    {
        super();
        this.state={count:1}
    }
    changeCount()
    {
        this.setState({
            count:this.state.count+1
        })
    }
  render() {
    const {name,age}=this.props;
   
    return (
      <div>
        <h1>Created by {name} in the age of {age} </h1>
        <h1>{this.state.count}</h1>
        <button onClick={()=>{this.changeCount()}}>Click Me</button>
      </div>
    )
  }
}

//export default Greet
