import { createStore } from "redux";
import reducer from "./comp/Reducer";

export const store = createStore(reducer);
