import React, { Component } from 'react'

class ConditonalClassEx extends Component {
 constructor()
 {
    super();
    this.state={flag:true}
 }


  render() {
    const trueEle=<div> Welcome Senathipathi </div>
   const falseEle=<div> Welcome Guest </div>
   return(this.state.flag? trueEle: falseEle);
  }
}

export default ConditonalClassEx
