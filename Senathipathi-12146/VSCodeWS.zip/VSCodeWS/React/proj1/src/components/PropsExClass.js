import React, { Component } from 'react'

class PropsExClass extends Component {
    
  render() {
    const{name,city}=this.props;
    return (
      <div>
        <h1>Welcome {name} from the city of {city} </h1>
      </div>
    )
  }
}

export default PropsExClass
