import React from 'react'

function PropsEx(props) {
    const{name,city}=props;
  return (
    <div>
      <h1>Welcome {name} from the city of {city} </h1>
      {props.children}
    </div>
  )
}

export default PropsEx
