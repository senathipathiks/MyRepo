import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import  Hello  from './components/HelloWorld';
import PropsEx from './components/PropsEx';
import PropsExClass from './components/PropsExClass';
import StateClass from './components/StateClass';
import StateFn from './components/StateFn';
import List from './components/List';
import UseEffectEx from './components/UseEffectEx';
import ConditionalRend from './components/ConditionalRend';
import HookFormEx from './components/HookFormEx';
import TextField from './components/TextField';
import ValidationForm from './components/ValidationForm';
import User from './components/User';
import ParentComp from './components/MemoEx/ParentComp';
import Main from './components/RouterEx/Main';
import NewComp from './components/ReduxEx/comp/NewComp';
import { Provider } from "react-redux";
import {store} from './components/ReduxEx/Configure-Store'
import FetchEx from './components/HttpProg/FetchEx';
import Axiosexam from './components/HttpProg/AxiosEx';


const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    {/* <App /> */}
    {/* <Hello /> */}
    {/* <PropsEx name="Senathipathi" city="Coimbatore"> This is Senathipathi's Functional Component </PropsEx>
    <PropsExClass name="Arun" city="Erode" />
    <StateClass />
    <StateFn /> */}
    {/* <StateClass />
    <UseEffectEx /> */}
    {/* <ConditionalRend /> */}
    {/* <HookFormEx /> */}
    {/* <TextField /> */}
    {/* <ValidationForm /> */}
    {/* <User /> */}
    {/* <ParentComp /> */}
    <Main />
    {/* <Provider store={store}>
      <NewComp />
    </Provider> */}
    {/* <FetchEx /> */}
    {/* <Axiosexam /> */}
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
