const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
module.exports={
    entry:'./app/index.js',

    module: {
        rules: [
          {
            test: /\.css$/i,
            use: ["style-loader", "css-loader"],
          },
          {
            test: /\.svg$/,
            use: 'svg-inline-loader'
         },
         {
            test: /\.(js)$/,
            use: 'babel-loader'
         },


        ],
      },
    
    plugins: [new HtmlWebpackPlugin()], 

    output: {
        path: path.resolve(__dirname, 'dist'),
        filename: 'bundle.js',
      },
    mode: 'production',

};