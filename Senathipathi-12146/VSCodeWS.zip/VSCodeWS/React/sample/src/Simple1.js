import React from 'react'

function Simple1() {
  return (
    <div>
      <h1>Created by Senathipathi </h1>
    </div>
  )
}

export default Simple1
