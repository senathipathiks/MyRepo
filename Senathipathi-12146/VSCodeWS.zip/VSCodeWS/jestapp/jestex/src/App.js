//import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <h1>Welcome to My Page !!!</h1>
      <br />
     <h2> Hi Welcome to Rele</h2>
    </div>
  );
}

export default App;
