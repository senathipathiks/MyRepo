document.write("<h1><font color=blue>Hello World</font></h1>");
